<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindlu");
}
include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MARNIES BAKERY</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="marniesbakery.png" width="30%">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <style>
      body{
        background-image:url('a.jpg');
        backdrop-filter:blur(4px);
      }
      header {
        background:rgba(255,2255,2255,0.5);
      }
      article{
        background-color:rgba(255,255,255,0.5);
        backdrop-filter:blur(5px);
        padding:1rem;
      }
    </style>
</head>
<body>
<nav class="navbar sticky-top navbar-expand-lg" style="background-color:beige;">
  <div class="container-fluid">
      <img src="marniesbakery.png" width="100px" alt="">
    <a class="navbar-brand" href="#">MARNIES BAKERY</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor03">
      <ul class="navbar-nav me-auto">
          <li class="nav-item">
        
        </li>
      
      </ul>
      <form class="d-flex">
      <a class="btn btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="fa-solid fa-plus"></i></a>
        <a href="logout.php" class= "btn btn-secondary"><i class="fa-solid fa-arrow-right"></i></a>
      </form>
    </div>
  </div>
</nav>
<!-- Modal Tambah -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Form Tambah Postingan</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
                  <label for="foto" class="form-label">image</label><br>
                  <input type="file" name="foto" id="" class="form-control"><br>

                  <label for="caption" class="form-label">caption</label><br>
                  <input type="text" name="caption" id="" class="form-control"><br>

                  <label for="lokasi" class="form-label">lokasi</label><br>
                  <input type="text" name="lokasi" id="" class="form-control"><br>

                  <input type="submit" value="simpan" name="simpan" class="btn btn-secondary">
                  <a href="index.php" class="btn btn-dark">kembali</a>

              </form>                  
                </div>
            </div>
        </div>
    </div>
    </div>
    
    <br>
   
    <?php while ($post = mysqli_fetch_assoc($query)){?>
        <div class="container">
    <!-- Postingan 1 -->
    <div class="row">
        <div class="col-md-4 mx-auto">
            <div class="card mb-4">
                <img src="images/<?=$post['foto']?>" class="card-img-top" alt="..." width="10px">
    </div>
                <div class="card-body">
                    <h5 class="card-title"><strong>@<?=$_SESSION['login']?></strong></h5>
                    <p class="card-text"><?=$post['caption']?></p>
                    <p class="card-text"><?=$post['lokasi']?></p>
                    
                    <a href="hapus.php?no=<?=$post['no']?>" class="btn btn-primary" onclick="return confirm('Apakah anda yakin ingin menghapus data ini?')"><i class="fas fa-trash"></i></i></a>
                    <!-- <a href="edit.php?no=<?=$post['no']?>" class="btn btn-secondary"><i class="fas fa-edit"></i></a> -->
                    <a class="btn btn-secondary" data-bs-toggle="modal" data-bs-target=
                    "#staticBackdrop<?=$post['no']?>"><i class="fa fa-edit"></i></a>
                </div>
            </div>
        </div>
    </div> <br>

    <div class="modal fade" id="staticBackdrop<?=$post['no']?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Form Tambah Postingan</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">
        

          <label for="">Foto</label>
        <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" class="form-control"><br><br>
        <label for="">Caption</label>
        <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" class="form-control" ><br><br>
         <label for="">Lokasi</label>
        <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" class="form-control" ><br><br>
        <img src="images/<?= $post['foto'] ?>" width="100" alt="" ><br><br>
        <input type="submit" value="Edit" name="update" class="btn btn-secondary">
        <a href="index.php" class="btn btn-dark">kembali</a>
    </form>           
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
   
    
</body>
</html>


